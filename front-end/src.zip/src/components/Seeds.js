import React from "react";

function Seeds() {

  return(
    <div>
    <h1>Seeds</h1>
  </div>  
  );
}

export default Seeds;

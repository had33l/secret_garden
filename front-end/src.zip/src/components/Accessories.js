import React from "react";

function Accessories() {
  return(
    <div>
      <h1>Accessories</h1>
    </div>
  );
}

export default Accessories;

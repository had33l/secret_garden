import React from "react";

function PlantDetails() {

  return(
    <div>
    <h1>Plant Details</h1>
  </div>  
  );
}

export default PlantDetails;

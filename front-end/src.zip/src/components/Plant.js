import React from "react";

function Plant() {

  return(
    <div>
    <h1>Plant</h1>
  </div>  
  );
}

export default Plant;

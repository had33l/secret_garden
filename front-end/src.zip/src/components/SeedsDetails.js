import React from "react";

function SeedsDetails() {
  return (
    <div>
      <h1>Seeds Details</h1>
    </div>
  );
}

export default SeedsDetails;

import React from "react";

function AccessoriesDetails() {
  return(
    <div>
      <h1>Accessories Details</h1>
    </div>
  );
}

export default AccessoriesDetails;
